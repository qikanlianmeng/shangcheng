<?php

namespace app\common\model;
use think\Model;

class PayLog extends Model
{
    // 开启自动写入时间戳字段
    protected $autoWriteTimestamp = true;

}

