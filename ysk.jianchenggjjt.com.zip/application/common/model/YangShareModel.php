<?php

namespace app\common\model;
use think\Model;
use think\Db;

class YangShareModel extends Model
{
    protected $name = 'yang_share';
    protected $autoWriteTimestamp = true;   // 开启自动写入时间戳


}