<?php

return [
    //模板参数替换
    'view_replace_str' =>[
        '__PUBLIC__'=>'/static/wapapp/public',
        '__CSS__' => '/static/wapapp/shop/css',
        '__JS__'  => '/static/wapapp/shop/js',
        '__IMG__' => '/static/wapapp/shop/images',
    ],
    'app_trace'=>false,
];
