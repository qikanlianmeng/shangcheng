<?php
/**
 * Created by PhpStorm.
 * User: tianfeiwen
 * Date: 2017/9/15
 * Time: 9:45
 */
namespace app\admin\model;

use think\Model;
use think\Db;

class Order extends Model
{
    protected $pk = 'order_id';
}