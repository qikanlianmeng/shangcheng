<?php

return [
    //模板参数替换
    'view_replace_str' =>[
        '__PUBLIC__'=>'/static/mob/public',
        '__CSS__' => '/static/mob/shop/css',
        '__JS__'  => '/static/mob/shop/js',
        '__IMG__' => '/static/mob/shop/images',
    ],
    'app_trace'=>false,
];
